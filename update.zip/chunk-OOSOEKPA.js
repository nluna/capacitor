import{a}from"./chunk-YATWPXT7.js";import"./chunk-LIG2ILL7.js";import"./chunk-YGKHJPPU.js";export{a as mdTransitionAnimation};
