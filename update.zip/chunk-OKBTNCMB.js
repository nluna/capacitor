var t=function(M){return M.LIMIT="Limitada",M.MARKET="Mercado",M.STOP_LIMIT="Stop Limit",M.MARKET_LIMIT="MTL",M}(t||{});export{t as a};
