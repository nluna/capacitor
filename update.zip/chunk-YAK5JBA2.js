var t=class{constructor(s,c){this.title=s,this.text=c}};export{t as a};
