import{b as e}from"./chunk-BYIKF3MC.js";var t=e("Device",{web:()=>import("./chunk-CRIGASB5.js").then(r=>new r.DeviceWeb)});export{t as a};
