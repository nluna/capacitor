import{b as r}from"./chunk-BYIKF3MC.js";var t=r("Browser",{web:()=>import("./chunk-SH3YP7PP.js").then(e=>new e.BrowserWeb)});export{t as a};
