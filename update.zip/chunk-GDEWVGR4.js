import{a}from"./chunk-E7ZOKENL.js";import"./chunk-YGKHJPPU.js";export{a as startFocusVisible};
